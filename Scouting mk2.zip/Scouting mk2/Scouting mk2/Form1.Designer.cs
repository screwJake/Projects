﻿namespace Scouting_mk2
    {
    partial class Form1
        {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
            {
            if (disposing && (components != null))
                {
                components.Dispose();
                }
            base.Dispose(disposing);
            }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
            {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.TeamBox = new System.Windows.Forms.TextBox();
            this.MatchBox = new System.Windows.Forms.TextBox();
            this.NameBox = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.AutoBarOne = new System.Windows.Forms.TrackBar();
            this.AutoBarTwo = new System.Windows.Forms.TrackBar();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.AutoLowOne = new System.Windows.Forms.TextBox();
            this.AutoLowTwo = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.AutoGearText = new System.Windows.Forms.TextBox();
            this.AutoGearDown = new System.Windows.Forms.Button();
            this.AutoGearUp = new System.Windows.Forms.Button();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.AutoHighText = new System.Windows.Forms.TextBox();
            this.AutoHighDown = new System.Windows.Forms.Button();
            this.AutoHighUp = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.TeleLow1 = new System.Windows.Forms.TextBox();
            this.TeleLow2 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.TeleGearText = new System.Windows.Forms.TextBox();
            this.TeleGearDown = new System.Windows.Forms.Button();
            this.TeleGearUp = new System.Windows.Forms.Button();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.GearBool = new System.Windows.Forms.CheckBox();
            this.ScaleBool = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.TeleHighText = new System.Windows.Forms.TextBox();
            this.TeleHighDown = new System.Windows.Forms.Button();
            this.TeleHighUp = new System.Windows.Forms.Button();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.NotesText = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.R1 = new System.Windows.Forms.RadioButton();
            this.R2 = new System.Windows.Forms.RadioButton();
            this.R3 = new System.Windows.Forms.RadioButton();
            this.R4 = new System.Windows.Forms.RadioButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AutoBarOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AutoBarTwo)).BeginInit();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1308, 879);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel14);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1300, 850);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Pre match";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.Controls.Add(this.tableLayoutPanel15, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.pictureBox2, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.button1, 0, 1);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel14.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 2;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(1292, 842);
            this.tableLayoutPanel14.TabIndex = 0;
            this.tableLayoutPanel14.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel14_Paint);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Controls.Add(this.TeamBox, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.MatchBox, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.NameBox, 0, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel15.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(638, 413);
            this.tableLayoutPanel15.TabIndex = 0;
            // 
            // TeamBox
            // 
            this.tableLayoutPanel15.SetColumnSpan(this.TeamBox, 2);
            this.TeamBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeamBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeamBox.Location = new System.Drawing.Point(4, 210);
            this.TeamBox.Margin = new System.Windows.Forms.Padding(4);
            this.TeamBox.Multiline = true;
            this.TeamBox.Name = "TeamBox";
            this.TeamBox.Size = new System.Drawing.Size(630, 199);
            this.TeamBox.TabIndex = 2;
            this.TeamBox.Text = "Team number:  ";
            // 
            // MatchBox
            // 
            this.MatchBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MatchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MatchBox.Location = new System.Drawing.Point(323, 4);
            this.MatchBox.Margin = new System.Windows.Forms.Padding(4);
            this.MatchBox.Multiline = true;
            this.MatchBox.Name = "MatchBox";
            this.MatchBox.Size = new System.Drawing.Size(311, 198);
            this.MatchBox.TabIndex = 1;
            this.MatchBox.Text = "Match: ";
            // 
            // NameBox
            // 
            this.NameBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NameBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameBox.Location = new System.Drawing.Point(4, 4);
            this.NameBox.Margin = new System.Windows.Forms.Padding(4);
            this.NameBox.Multiline = true;
            this.NameBox.Name = "NameBox";
            this.NameBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.NameBox.Size = new System.Drawing.Size(311, 198);
            this.NameBox.TabIndex = 0;
            this.NameBox.Text = "Name: ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.ImageLocation = "C:\\Users\\Nate Lancto\\Documents\\Visual Studio 2015\\Projects\\Scouting mk2\\Scouting " +
    "mk2\\First.png";
            this.pictureBox2.Location = new System.Drawing.Point(650, 4);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(638, 413);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(4, 425);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(638, 413);
            this.button1.TabIndex = 2;
            this.button1.Text = "Select save location";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel22);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1300, 850);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Auto";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel21, 1, 1);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel19, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel11, 0, 1);
            this.tableLayoutPanel22.Controls.Add(this.checkBox1, 1, 0);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel22.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 2;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(1292, 842);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 1;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Controls.Add(this.AutoBarOne, 0, 2);
            this.tableLayoutPanel21.Controls.Add(this.AutoBarTwo, 0, 3);
            this.tableLayoutPanel21.Controls.Add(this.textBox23, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel20, 0, 1);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(650, 425);
            this.tableLayoutPanel21.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 4;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(638, 413);
            this.tableLayoutPanel21.TabIndex = 0;
            // 
            // AutoBarOne
            // 
            this.AutoBarOne.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoBarOne.Location = new System.Drawing.Point(4, 251);
            this.AutoBarOne.Margin = new System.Windows.Forms.Padding(4);
            this.AutoBarOne.Maximum = 100;
            this.AutoBarOne.Name = "AutoBarOne";
            this.AutoBarOne.Size = new System.Drawing.Size(630, 74);
            this.AutoBarOne.TabIndex = 0;
            this.AutoBarOne.Scroll += new System.EventHandler(this.AutoS1);
            // 
            // AutoBarTwo
            // 
            this.AutoBarTwo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoBarTwo.Location = new System.Drawing.Point(4, 333);
            this.AutoBarTwo.Margin = new System.Windows.Forms.Padding(4);
            this.AutoBarTwo.Maximum = 100;
            this.AutoBarTwo.Name = "AutoBarTwo";
            this.AutoBarTwo.Size = new System.Drawing.Size(630, 76);
            this.AutoBarTwo.TabIndex = 1;
            this.AutoBarTwo.Scroll += new System.EventHandler(this.AutoBarTwo_Scroll);
            // 
            // textBox23
            // 
            this.textBox23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox23.Font = new System.Drawing.Font("Microsoft Tai Le", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(4, 4);
            this.textBox23.Margin = new System.Windows.Forms.Padding(4);
            this.textBox23.Multiline = true;
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(630, 74);
            this.textBox23.TabIndex = 3;
            this.textBox23.Text = "Low Goal";
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 3;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel20.Controls.Add(this.AutoLowOne, 0, 0);
            this.tableLayoutPanel20.Controls.Add(this.AutoLowTwo, 2, 0);
            this.tableLayoutPanel20.Controls.Add(this.textBox22, 1, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(4, 86);
            this.tableLayoutPanel20.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(630, 157);
            this.tableLayoutPanel20.TabIndex = 4;
            // 
            // AutoLowOne
            // 
            this.AutoLowOne.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoLowOne.Font = new System.Drawing.Font("Microsoft Tai Le", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoLowOne.Location = new System.Drawing.Point(4, 4);
            this.AutoLowOne.Margin = new System.Windows.Forms.Padding(4);
            this.AutoLowOne.Multiline = true;
            this.AutoLowOne.Name = "AutoLowOne";
            this.AutoLowOne.ReadOnly = true;
            this.AutoLowOne.Size = new System.Drawing.Size(202, 149);
            this.AutoLowOne.TabIndex = 0;
            this.AutoLowOne.Text = "0";
            this.AutoLowOne.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // AutoLowTwo
            // 
            this.AutoLowTwo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoLowTwo.Font = new System.Drawing.Font("Microsoft Tai Le", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoLowTwo.Location = new System.Drawing.Point(424, 4);
            this.AutoLowTwo.Margin = new System.Windows.Forms.Padding(4);
            this.AutoLowTwo.Multiline = true;
            this.AutoLowTwo.Name = "AutoLowTwo";
            this.AutoLowTwo.ReadOnly = true;
            this.AutoLowTwo.Size = new System.Drawing.Size(202, 149);
            this.AutoLowTwo.TabIndex = 1;
            this.AutoLowTwo.Text = "0";
            // 
            // textBox22
            // 
            this.textBox22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(214, 4);
            this.textBox22.Margin = new System.Windows.Forms.Padding(4);
            this.textBox22.Multiline = true;
            this.textBox22.Name = "textBox22";
            this.textBox22.ReadOnly = true;
            this.textBox22.Size = new System.Drawing.Size(202, 149);
            this.textBox22.TabIndex = 2;
            this.textBox22.Text = "- To -";
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.textBox19, 0, 0);
            this.tableLayoutPanel19.Controls.Add(this.tableLayoutPanel18, 0, 1);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel19.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(638, 413);
            this.tableLayoutPanel19.TabIndex = 1;
            // 
            // textBox19
            // 
            this.textBox19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox19.Font = new System.Drawing.Font("Microsoft Tai Le", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(4, 4);
            this.textBox19.Margin = new System.Windows.Forms.Padding(4);
            this.textBox19.Multiline = true;
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(630, 74);
            this.textBox19.TabIndex = 0;
            this.textBox19.Text = "Gears";
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel13, 0, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(4, 86);
            this.tableLayoutPanel18.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 2;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(630, 323);
            this.tableLayoutPanel18.TabIndex = 1;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.AutoGearText, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.AutoGearDown, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.AutoGearUp, 1, 1);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(622, 250);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // AutoGearText
            // 
            this.tableLayoutPanel13.SetColumnSpan(this.AutoGearText, 2);
            this.AutoGearText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoGearText.Font = new System.Drawing.Font("Microsoft Tai Le", 45F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoGearText.Location = new System.Drawing.Point(4, 4);
            this.AutoGearText.Margin = new System.Windows.Forms.Padding(4);
            this.AutoGearText.Multiline = true;
            this.AutoGearText.Name = "AutoGearText";
            this.AutoGearText.Size = new System.Drawing.Size(614, 117);
            this.AutoGearText.TabIndex = 0;
            this.AutoGearText.Text = "0";
            this.AutoGearText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoGearDown
            // 
            this.AutoGearDown.BackColor = System.Drawing.Color.WhiteSmoke;
            this.AutoGearDown.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoGearDown.Font = new System.Drawing.Font("Microsoft Tai Le", 45F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoGearDown.Location = new System.Drawing.Point(4, 129);
            this.AutoGearDown.Margin = new System.Windows.Forms.Padding(4);
            this.AutoGearDown.Name = "AutoGearDown";
            this.AutoGearDown.Size = new System.Drawing.Size(303, 117);
            this.AutoGearDown.TabIndex = 1;
            this.AutoGearDown.Text = "-";
            this.AutoGearDown.UseVisualStyleBackColor = false;
            this.AutoGearDown.Click += new System.EventHandler(this.AutoGearDown_Click);
            // 
            // AutoGearUp
            // 
            this.AutoGearUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.AutoGearUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoGearUp.Font = new System.Drawing.Font("Microsoft Tai Le", 45F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoGearUp.Location = new System.Drawing.Point(315, 129);
            this.AutoGearUp.Margin = new System.Windows.Forms.Padding(4);
            this.AutoGearUp.Name = "AutoGearUp";
            this.AutoGearUp.Size = new System.Drawing.Size(303, 117);
            this.AutoGearUp.TabIndex = 2;
            this.AutoGearUp.Text = "+";
            this.AutoGearUp.UseVisualStyleBackColor = false;
            this.AutoGearUp.Click += new System.EventHandler(this.AutoGearUp_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.textBox11, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 1);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(4, 425);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(638, 413);
            this.tableLayoutPanel11.TabIndex = 2;
            // 
            // textBox11
            // 
            this.textBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox11.Font = new System.Drawing.Font("Microsoft Tai Le", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(4, 4);
            this.textBox11.Margin = new System.Windows.Forms.Padding(4);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(630, 74);
            this.textBox11.TabIndex = 0;
            this.textBox11.Text = "High Goal";
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.AutoHighText, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.AutoHighDown, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.AutoHighUp, 1, 1);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(4, 86);
            this.tableLayoutPanel12.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(630, 323);
            this.tableLayoutPanel12.TabIndex = 1;
            // 
            // AutoHighText
            // 
            this.tableLayoutPanel12.SetColumnSpan(this.AutoHighText, 2);
            this.AutoHighText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoHighText.Font = new System.Drawing.Font("Microsoft Tai Le", 50F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoHighText.Location = new System.Drawing.Point(4, 4);
            this.AutoHighText.Margin = new System.Windows.Forms.Padding(4);
            this.AutoHighText.Multiline = true;
            this.AutoHighText.Name = "AutoHighText";
            this.AutoHighText.Size = new System.Drawing.Size(622, 153);
            this.AutoHighText.TabIndex = 0;
            this.AutoHighText.Text = "0";
            this.AutoHighText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AutoHighDown
            // 
            this.AutoHighDown.BackColor = System.Drawing.Color.WhiteSmoke;
            this.AutoHighDown.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoHighDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoHighDown.Location = new System.Drawing.Point(4, 165);
            this.AutoHighDown.Margin = new System.Windows.Forms.Padding(4);
            this.AutoHighDown.Name = "AutoHighDown";
            this.AutoHighDown.Size = new System.Drawing.Size(307, 154);
            this.AutoHighDown.TabIndex = 1;
            this.AutoHighDown.Text = "-";
            this.AutoHighDown.UseVisualStyleBackColor = false;
            this.AutoHighDown.Click += new System.EventHandler(this.AutoHighDown_Click);
            // 
            // AutoHighUp
            // 
            this.AutoHighUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.AutoHighUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AutoHighUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AutoHighUp.Location = new System.Drawing.Point(319, 165);
            this.AutoHighUp.Margin = new System.Windows.Forms.Padding(4);
            this.AutoHighUp.Name = "AutoHighUp";
            this.AutoHighUp.Size = new System.Drawing.Size(307, 154);
            this.AutoHighUp.TabIndex = 2;
            this.AutoHighUp.Text = "+";
            this.AutoHighUp.UseVisualStyleBackColor = false;
            this.AutoHighUp.Click += new System.EventHandler(this.AutoHighUp_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tableLayoutPanel1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1300, 850);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Tele";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel10, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel16, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1292, 842);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.trackBar1, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.trackBar2, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.textBox2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(650, 382);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(638, 370);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // trackBar1
            // 
            this.trackBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trackBar1.Location = new System.Drawing.Point(4, 226);
            this.trackBar1.Margin = new System.Windows.Forms.Padding(4);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(630, 66);
            this.trackBar1.TabIndex = 0;
            this.trackBar1.Scroll += new System.EventHandler(this.TeleBar1_Scroll);
            // 
            // trackBar2
            // 
            this.trackBar2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trackBar2.Location = new System.Drawing.Point(4, 300);
            this.trackBar2.Margin = new System.Windows.Forms.Padding(4);
            this.trackBar2.Maximum = 100;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(630, 66);
            this.trackBar2.TabIndex = 1;
            this.trackBar2.Scroll += new System.EventHandler(this.TeleBar2_Scroll);
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Tai Le", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(4, 4);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(630, 66);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "Low Goal";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Controls.Add(this.TeleLow1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.TeleLow2, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBox4, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(4, 78);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(630, 140);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // TeleLow1
            // 
            this.TeleLow1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeleLow1.Font = new System.Drawing.Font("Microsoft Tai Le", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleLow1.Location = new System.Drawing.Point(4, 4);
            this.TeleLow1.Margin = new System.Windows.Forms.Padding(4);
            this.TeleLow1.Multiline = true;
            this.TeleLow1.Name = "TeleLow1";
            this.TeleLow1.ReadOnly = true;
            this.TeleLow1.Size = new System.Drawing.Size(202, 132);
            this.TeleLow1.TabIndex = 0;
            this.TeleLow1.Text = "0";
            this.TeleLow1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TeleLow2
            // 
            this.TeleLow2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeleLow2.Font = new System.Drawing.Font("Microsoft Tai Le", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleLow2.Location = new System.Drawing.Point(424, 4);
            this.TeleLow2.Margin = new System.Windows.Forms.Padding(4);
            this.TeleLow2.Multiline = true;
            this.TeleLow2.Name = "TeleLow2";
            this.TeleLow2.ReadOnly = true;
            this.TeleLow2.Size = new System.Drawing.Size(202, 132);
            this.TeleLow2.TabIndex = 1;
            this.TeleLow2.Text = "0";
            // 
            // textBox4
            // 
            this.textBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(214, 4);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(202, 132);
            this.textBox4.TabIndex = 2;
            this.textBox4.Text = "- To -";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.textBox5, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(638, 370);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // textBox5
            // 
            this.textBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Tai Le", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(4, 4);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(630, 66);
            this.textBox5.TabIndex = 0;
            this.textBox5.Text = "Gears";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel9, 0, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(4, 78);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(630, 288);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.TeleGearText, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.TeleGearDown, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.TeleGearUp, 1, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(4, 4);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(622, 222);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // TeleGearText
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.TeleGearText, 2);
            this.TeleGearText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeleGearText.Font = new System.Drawing.Font("Microsoft Tai Le", 45F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleGearText.Location = new System.Drawing.Point(4, 4);
            this.TeleGearText.Margin = new System.Windows.Forms.Padding(4);
            this.TeleGearText.Multiline = true;
            this.TeleGearText.Name = "TeleGearText";
            this.TeleGearText.Size = new System.Drawing.Size(614, 103);
            this.TeleGearText.TabIndex = 0;
            this.TeleGearText.Text = "0";
            this.TeleGearText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TeleGearDown
            // 
            this.TeleGearDown.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TeleGearDown.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeleGearDown.Font = new System.Drawing.Font("Microsoft Tai Le", 45F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleGearDown.Location = new System.Drawing.Point(4, 115);
            this.TeleGearDown.Margin = new System.Windows.Forms.Padding(4);
            this.TeleGearDown.Name = "TeleGearDown";
            this.TeleGearDown.Size = new System.Drawing.Size(303, 103);
            this.TeleGearDown.TabIndex = 1;
            this.TeleGearDown.Text = "-";
            this.TeleGearDown.UseVisualStyleBackColor = false;
            this.TeleGearDown.Click += new System.EventHandler(this.TeleGearDown_Click);
            // 
            // TeleGearUp
            // 
            this.TeleGearUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TeleGearUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeleGearUp.Font = new System.Drawing.Font("Microsoft Tai Le", 45F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleGearUp.Location = new System.Drawing.Point(315, 115);
            this.TeleGearUp.Margin = new System.Windows.Forms.Padding(4);
            this.TeleGearUp.Name = "TeleGearUp";
            this.TeleGearUp.Size = new System.Drawing.Size(303, 103);
            this.TeleGearUp.TabIndex = 2;
            this.TeleGearUp.Text = "+";
            this.TeleGearUp.UseVisualStyleBackColor = false;
            this.TeleGearUp.Click += new System.EventHandler(this.TeleGearUp_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.GearBool, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.ScaleBool, 1, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(4, 234);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(622, 50);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // GearBool
            // 
            this.GearBool.AutoSize = true;
            this.GearBool.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GearBool.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GearBool.Location = new System.Drawing.Point(4, 4);
            this.GearBool.Margin = new System.Windows.Forms.Padding(4);
            this.GearBool.Name = "GearBool";
            this.GearBool.Size = new System.Drawing.Size(303, 42);
            this.GearBool.TabIndex = 0;
            this.GearBool.Text = "Gear from ground";
            this.GearBool.UseVisualStyleBackColor = true;
            this.GearBool.CheckedChanged += new System.EventHandler(this.GearBool_CheckedChanged);
            // 
            // ScaleBool
            // 
            this.ScaleBool.AutoSize = true;
            this.ScaleBool.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ScaleBool.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScaleBool.Location = new System.Drawing.Point(315, 4);
            this.ScaleBool.Margin = new System.Windows.Forms.Padding(4);
            this.ScaleBool.Name = "ScaleBool";
            this.ScaleBool.Size = new System.Drawing.Size(303, 42);
            this.ScaleBool.TabIndex = 1;
            this.ScaleBool.Text = "Climbed";
            this.ScaleBool.UseVisualStyleBackColor = true;
            this.ScaleBool.CheckedChanged += new System.EventHandler(this.ScaleBool_CheckedChanged);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.textBox7, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel8, 0, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(4, 382);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(638, 370);
            this.tableLayoutPanel7.TabIndex = 2;
            // 
            // textBox7
            // 
            this.textBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Tai Le", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(4, 4);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(630, 66);
            this.textBox7.TabIndex = 0;
            this.textBox7.Text = "High Goal";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.TeleHighText, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.TeleHighDown, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.TeleHighUp, 1, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(4, 78);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(630, 288);
            this.tableLayoutPanel8.TabIndex = 1;
            // 
            // TeleHighText
            // 
            this.tableLayoutPanel8.SetColumnSpan(this.TeleHighText, 2);
            this.TeleHighText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeleHighText.Font = new System.Drawing.Font("Microsoft Tai Le", 50F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleHighText.Location = new System.Drawing.Point(4, 4);
            this.TeleHighText.Margin = new System.Windows.Forms.Padding(4);
            this.TeleHighText.Multiline = true;
            this.TeleHighText.Name = "TeleHighText";
            this.TeleHighText.Size = new System.Drawing.Size(622, 136);
            this.TeleHighText.TabIndex = 0;
            this.TeleHighText.Text = "0";
            this.TeleHighText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TeleHighDown
            // 
            this.TeleHighDown.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TeleHighDown.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeleHighDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleHighDown.Location = new System.Drawing.Point(4, 148);
            this.TeleHighDown.Margin = new System.Windows.Forms.Padding(4);
            this.TeleHighDown.Name = "TeleHighDown";
            this.TeleHighDown.Size = new System.Drawing.Size(307, 136);
            this.TeleHighDown.TabIndex = 1;
            this.TeleHighDown.Text = "-";
            this.TeleHighDown.UseVisualStyleBackColor = false;
            this.TeleHighDown.Click += new System.EventHandler(this.TeleHighDown_Click);
            // 
            // TeleHighUp
            // 
            this.TeleHighUp.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TeleHighUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TeleHighUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeleHighUp.Location = new System.Drawing.Point(319, 148);
            this.TeleHighUp.Margin = new System.Windows.Forms.Padding(4);
            this.TeleHighUp.Name = "TeleHighUp";
            this.TeleHighUp.Size = new System.Drawing.Size(307, 136);
            this.TeleHighUp.TabIndex = 2;
            this.TeleHighUp.Text = "+";
            this.TeleHighUp.UseVisualStyleBackColor = false;
            this.TeleHighUp.Click += new System.EventHandler(this.TeleHighUp_Click);
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.textBox9, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.NotesText, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(650, 4);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(638, 370);
            this.tableLayoutPanel10.TabIndex = 3;
            // 
            // textBox9
            // 
            this.textBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(4, 4);
            this.textBox9.Margin = new System.Windows.Forms.Padding(4);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(630, 66);
            this.textBox9.TabIndex = 0;
            this.textBox9.Text = "Notes";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NotesText
            // 
            this.NotesText.BackColor = System.Drawing.Color.WhiteSmoke;
            this.NotesText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NotesText.Font = new System.Drawing.Font("Microsoft Tai Le", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NotesText.Location = new System.Drawing.Point(4, 78);
            this.NotesText.Margin = new System.Windows.Forms.Padding(4);
            this.NotesText.Multiline = true;
            this.NotesText.Name = "NotesText";
            this.NotesText.Size = new System.Drawing.Size(630, 288);
            this.NotesText.TabIndex = 1;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 4;
            this.tableLayoutPanel1.SetColumnSpan(this.tableLayoutPanel16, 2);
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel16.Controls.Add(this.R1, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.R2, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.R3, 2, 0);
            this.tableLayoutPanel16.Controls.Add(this.R4, 3, 0);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(4, 760);
            this.tableLayoutPanel16.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(1284, 78);
            this.tableLayoutPanel16.TabIndex = 4;
            // 
            // R1
            // 
            this.R1.AutoSize = true;
            this.R1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.R1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R1.Location = new System.Drawing.Point(4, 4);
            this.R1.Margin = new System.Windows.Forms.Padding(4);
            this.R1.Name = "R1";
            this.R1.Size = new System.Drawing.Size(313, 70);
            this.R1.TabIndex = 0;
            this.R1.TabStop = true;
            this.R1.Text = "One rotor";
            this.R1.UseVisualStyleBackColor = true;
            this.R1.CheckedChanged += new System.EventHandler(this.R1_CheckedChanged);
            // 
            // R2
            // 
            this.R2.AutoSize = true;
            this.R2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.R2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R2.Location = new System.Drawing.Point(325, 4);
            this.R2.Margin = new System.Windows.Forms.Padding(4);
            this.R2.Name = "R2";
            this.R2.Size = new System.Drawing.Size(313, 70);
            this.R2.TabIndex = 1;
            this.R2.TabStop = true;
            this.R2.Text = "Two rotors";
            this.R2.UseVisualStyleBackColor = true;
            this.R2.CheckedChanged += new System.EventHandler(this.R2_CheckedChanged);
            // 
            // R3
            // 
            this.R3.AutoSize = true;
            this.R3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.R3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R3.Location = new System.Drawing.Point(646, 4);
            this.R3.Margin = new System.Windows.Forms.Padding(4);
            this.R3.Name = "R3";
            this.R3.Size = new System.Drawing.Size(313, 70);
            this.R3.TabIndex = 2;
            this.R3.TabStop = true;
            this.R3.Text = "Three rotors";
            this.R3.UseVisualStyleBackColor = true;
            this.R3.CheckedChanged += new System.EventHandler(this.R3_CheckedChanged);
            // 
            // R4
            // 
            this.R4.AutoSize = true;
            this.R4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.R4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R4.Location = new System.Drawing.Point(967, 4);
            this.R4.Margin = new System.Windows.Forms.Padding(4);
            this.R4.Name = "R4";
            this.R4.Size = new System.Drawing.Size(313, 70);
            this.R4.TabIndex = 3;
            this.R4.TabStop = true;
            this.R4.Text = "Four rotors";
            this.R4.UseVisualStyleBackColor = true;
            this.R4.CheckedChanged += new System.EventHandler(this.R4_CheckedChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button9);
            this.tabPage4.Controls.Add(this.pictureBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(1300, 850);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Post match";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(419, 28);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(183, 69);
            this.button9.TabIndex = 1;
            this.button9.Text = "Submit";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.submit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.ImageLocation = "C:\\Users\\Nate Lancto\\Documents\\Visual Studio 2015\\Projects\\Scouting mk2\\Scouting " +
    "mk2\\dean.jpg";
            this.pictureBox1.Location = new System.Drawing.Point(4, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1292, 842);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "txt";
            this.saveFileDialog1.FileName = "Output";
            this.saveFileDialog1.InitialDirectory = "Desktop";
            this.saveFileDialog1.RestoreDirectory = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(649, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(640, 415);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "Crossed Baseline";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 879);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AutoBarOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AutoBarTwo)).EndInit();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel20.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel16.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

            }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TextBox TeleLow1;
        private System.Windows.Forms.TextBox TeleLow2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TextBox TeleGearText;
        private System.Windows.Forms.Button TeleGearDown;
        private System.Windows.Forms.Button TeleGearUp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.CheckBox GearBool;
        private System.Windows.Forms.CheckBox ScaleBool;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TextBox TeleHighText;
        private System.Windows.Forms.Button TeleHighDown;
        private System.Windows.Forms.Button TeleHighUp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox NotesText;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.TrackBar AutoBarOne;
        private System.Windows.Forms.TrackBar AutoBarTwo;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.TextBox AutoLowOne;
        private System.Windows.Forms.TextBox AutoLowTwo;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TextBox AutoGearText;
        private System.Windows.Forms.Button AutoGearDown;
        private System.Windows.Forms.Button AutoGearUp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TextBox AutoHighText;
        private System.Windows.Forms.Button AutoHighDown;
        private System.Windows.Forms.Button AutoHighUp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.TextBox TeamBox;
        private System.Windows.Forms.TextBox MatchBox;
        private System.Windows.Forms.TextBox NameBox;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.RadioButton R1;
        private System.Windows.Forms.RadioButton R2;
        private System.Windows.Forms.RadioButton R3;
        private System.Windows.Forms.RadioButton R4;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.CheckBox checkBox1;
        }
    }

